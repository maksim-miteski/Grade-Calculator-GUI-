/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import login.Calculator;

/**
 *
 * @author Maksim
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField txt1;
    @FXML
    private TextField txt2;
    @FXML
    private TextField txt3;
    @FXML
    private TextField txt4;
    @FXML
    private TextField txt5;
    @FXML
    private TextField txt6;
    @FXML
    private TextField txt7;
    @FXML
    private TextField txt8;
    @FXML
    private TextField txt9;
    @FXML
    private TextField txt10;
    @FXML
    private Label output;
    @FXML
    private ImageView imageView;
    @FXML
    private Label output2;
    @FXML
    private Label output3;
    @FXML
    private Label final1;
    @FXML
    private Label final2;
    @FXML
    private Label final3;
    @FXML
    private Label final4;
    @FXML
    private Label final5;
    @FXML
    private TextField nameOfSub1;
    @FXML
    private TextField nameOfSub2;
    @FXML
    private TextField nameOfSub3;
    @FXML
    private TextField nameOfSub4;
    @FXML
    private TextField nameOfSub5;
    @FXML
    private Label n1;
    @FXML
    private Label n2;
    @FXML
    private Label n3;
    @FXML
    private Label n4;
    @FXML
    private Label n5;
    @FXML
    private Label n21;
    @FXML
    private Label n22;
    @FXML
    private Label n23;
    @FXML
    private Label n24;
    @FXML
    private Label n25;
    @FXML
    private TextArea error;
    //private Button logout;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
 
    
    @FXML
    private void OnCalculateClick(ActionEvent event) {
    double midGrade1=Integer.parseInt(txt1.getText());
   
   // if(txt1.getText().isEmpty())
    //error.setText("The Field can not be left blank. Please enter a valid value.");
    
     
    double midGrade6=Integer.parseInt(txt6.getText());
    double midGrade2=Integer.parseInt(txt2.getText());
    double midGrade7=Integer.parseInt(txt7.getText());
    double midGrade3=Integer.parseInt(txt3.getText());
    double midGrade8=Integer.parseInt(txt8.getText());
    double midGrade4=Integer.parseInt(txt4.getText());
    double midGrade9=Integer.parseInt(txt9.getText());
    double midGrade5=Integer.parseInt(txt5.getText());
    double midGrade10=Integer.parseInt(txt10.getText()); 
  
    
    double calSub1,calSub2,calSub3,calSub4,calSub5;
    
    calSub1=((midGrade1+midGrade6)/2);   
    if(midGrade1 >=0 && midGrade1<=100 && midGrade6 >=0 && midGrade6<=100){
    final1.setText(String.valueOf(calSub1));
      }else{
        final1.setText("Error");
       error.setText("Error, invalid input!Please enter a value from 0 to 100");
    }
       calSub2=((midGrade2+midGrade7)/2);
       if(midGrade2 >=0 && midGrade2<=100 && midGrade7>=0 && midGrade7 <=100){
     final2.setText(String.valueOf(calSub2));
       }else{
           final2.setText("Error");
          error.setText("Error, invalid input!Please enter a value from 0 to 100");
       }  
    calSub3=((midGrade3+midGrade8)/2);
       if(midGrade3 >=0 && midGrade3<=100 && midGrade8>=0 && midGrade8 <=100){
     final3.setText(String.valueOf(calSub3));
       }else{
           final3.setText("Error");
          error.setText("Error, invalid input!Please enter a value from 0 to 100");
       } 
     calSub4=((midGrade4+midGrade9)/2);
      if(midGrade4 >=0 && midGrade4<=100 && midGrade9>=0 && midGrade9 <=100){
     final4.setText(String.valueOf(calSub4));
       }else{
           final4.setText("Error");
          error.setText("Error, invalid input!Please enter a value from 0 to 100");
      }   
    calSub5=((midGrade5+midGrade10)/2);
      if(midGrade5 >=0 && midGrade5<=100 && midGrade10>=0 && midGrade10 <=100){
     final5.setText(String.valueOf(calSub5));
       }else{
           final5.setText("Error");
          error.setText("Error, invalid input!Please enter a value from 0 to 100");
      }
    
      //Calculating the final grades   
      double calculateMid1,calculateMid2,calculateFinal;
    calculateMid1=((midGrade1+midGrade2+midGrade3+midGrade4+midGrade5)/5);
    if(midGrade1<=100 && midGrade1>=0 && midGrade2<=100 && midGrade2>=0 && midGrade3<=100 && midGrade3>=0 
                     && midGrade4<=100 && midGrade4>=0 && midGrade5<=100 && midGrade5>=0){
         output.setText(String.valueOf(calculateMid1)); 
    }else
        output.setText("Error");
    
    
    calculateMid2=((midGrade6+midGrade7+midGrade8+midGrade9+midGrade10)/5);
    if(midGrade6<=100 && midGrade6>=0 && midGrade7<=100 && midGrade7>=0 && midGrade8<=100 && midGrade8>=0 
                     && midGrade9<=100 && midGrade9>=0 && midGrade10<=100 && midGrade10>=0){
         output2.setText(String.valueOf(calculateMid2)); 
    }else
        output2.setText("Error");
    
    
    calculateFinal=((calculateMid1+calculateMid2)/2);
    if(calculateMid1 >=0 && calculateMid1 <=100 && calculateMid2<=100 && calculateMid2 >=0){
       output3.setText(String.valueOf(calculateFinal));   
    }else
        output3.setText("Error");
}

    @FXML
    private void OnEnterClick(ActionEvent event) {
        
      String name1=nameOfSub1.getText();
      n1.setText(name1);
      n21.setText(name1);
      String name2=nameOfSub2.getText();
      n2.setText(name2);
      n22.setText(name2);
      String name3=nameOfSub3.getText();
      n3.setText(name3);
      n23.setText(name3);
      String name4=nameOfSub4.getText();
      n4.setText(name4);
      n24.setText(name4);
      String name5=nameOfSub5.getText();
      n5.setText(name5);
      n25.setText(name5);
    }
  


    @FXML
    private void save(ActionEvent event) throws IOException {
    File file=new File("/Users/Maksim/NetBeansProjects/Data.txt");     
   
     try{
           PrintWriter file1=new PrintWriter("Data.txt");
           file1.println("Name of subjects and the final overall scores:");
           
                 file1.println(nameOfSub1.getText());
                 file1.println(nameOfSub2.getText());
                 file1.println(nameOfSub3.getText());
                 file1.println(nameOfSub4.getText());
                 file1.println(nameOfSub5.getText());
                 
                 file1.println(txt1.getText());
                 file1.println(txt2.getText());
                 file1.println(txt3.getText());
                 file1.println(txt4.getText());
                 file1.println(txt5.getText());
                 file1.println(txt6.getText());
                 file1.println(txt7.getText());
                 file1.println(txt8.getText());
                 file1.println(txt9.getText());
                 file1.println(txt10.getText());
                 
                 file1.println(final1.getText());
                 file1.println(final2.getText());
                 file1.println(final3.getText());
                 file1.println(final4.getText());
                 file1.println(final5.getText());
                 
                 file1.println(output.getText());
                 file1.println(output2.getText());
                 file1.println(output3.getText());
            file1.flush();
            file1.close();
       } catch (FileNotFoundException ex) {
                        Logger.getLogger(Calculator.class.getName()).log(Level.SEVERE, null, ex);
      }
    }

    @FXML
    private void restore(ActionEvent event) {
        
                    try {
                        Scanner scan = new Scanner(new File("Data.txt"));
                        String s=scan.nextLine();
                        
                        String s1=scan.nextLine();
                        nameOfSub1.setText(s1);
                        String s2=scan.nextLine();
                        nameOfSub2.setText(s2);
                        String s3=scan.nextLine();
                        nameOfSub3.setText(s3);
                        String s4=scan.nextLine();
                        nameOfSub4.setText(s4);
                        String s5=scan.nextLine();
                        nameOfSub5.setText(s5);
     
                        String s6=scan.nextLine();
                        txt1.setText(s6);
                         String s7=scan.nextLine();
                        txt2.setText(s7);
                         String s8=scan.nextLine();
                        txt3.setText(s8);
                         String s9=scan.nextLine();
                        txt4.setText(s9);
                         String s10=scan.nextLine();
                        txt5.setText(s10);
                         String s11=scan.nextLine();
                        txt6.setText(s11);
                         String s12=scan.nextLine();
                        txt7.setText(s12);
                         String s13=scan.nextLine();
                        txt8.setText(s13);
                         String s14=scan.nextLine();
                        txt9.setText(s14);
                         String s15=scan.nextLine();
                        txt10.setText(s15);
                        
                        String s16=scan.nextLine();
                        final1.setText(s16);
                        String s17=scan.nextLine();
                        final2.setText(s17);
                        String s18=scan.nextLine();
                        final3.setText(s18);
                        String s19=scan.nextLine();
                        final4.setText(s19);
                        String s20=scan.nextLine();
                        final5.setText(s20);
                        
                       String s21=scan.nextLine();
                       output.setText(s21);
                       String s22=scan.nextLine();
                       output2.setText(s22);
                       String s23=scan.nextLine();
                       output3.setText(s23);
                       

                    } catch (Exception e) {
                        Alert alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error Restoring File");
                        alert.setHeaderText("Error encountered:");
                        alert.setContentText("(The system cannot the file specified)");
                    }
    }

    @FXML
    private void clear(ActionEvent event) {
        nameOfSub1.clear();
        nameOfSub2.clear();
        nameOfSub3.clear();
        nameOfSub4.clear();
        nameOfSub5.clear();
       
        txt1.clear();
        txt2.clear();
        txt3.clear();
        txt4.clear();
        txt5.clear();
        txt6.clear();
        txt7.clear();
        txt8.clear();
        txt9.clear();
        txt10.clear();
         
        error.clear();
       
        n1.setText("");
        n2.setText("");
        n3.setText("");
        n4.setText("");
        n5.setText("");
        
        n21.setText("");
        n22.setText("");
        n23.setText("");
        n24.setText("");
        n25.setText("");
        
        final1.setText("");
        final2.setText("");
        final3.setText("");
        final4.setText("");
        final5.setText("");
     
        output.setText("");
        output2.setText("");
        output3.setText("");
    }
} 