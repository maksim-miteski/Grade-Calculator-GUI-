/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *Program that calculates the average score from every subject separately and the overall from all subjects together.
 * @author Maksim
 * @version May 2020 Computer Interface Programming
 */
public class Calculator extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Grade Calculator");
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root, 1000, 500);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        launch(args);
   
    /* ServerSocket s=new ServerSocket(8080);
     while(true){
     Socket p = s.accept(); 
      }*/
    }
  }
